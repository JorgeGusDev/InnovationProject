package com.example.eduni.myapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.hardware.display.DisplayManager;
import android.os.AsyncTask;
import android.os.PowerManager;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;

import java.sql.Time;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    private Button mStartButton;
    private Button mFinishButton;
    private Button mUpdateButton;
    private Chronometer mChronometer; //este es el cronometro general que contara el tiempo de comienzo a fin
    private Chronometer mChronometerDistraction; // este es el cronometro que contara el tiempo de distraccion

    private long lastPause; //esta variable se usa para buscar asignarle el valor de donde pauso el cronometro y de ahi continuar a contar el cronometro
    private boolean TimeRunning= false; // usa este booleano para saber si el tiempo esta corriendo
    private boolean ResumeTimer = false;//usa este booleano para saber si se seguira en el tiempo que se quedo cuando se apago la pantalla

    //variables de piechart
    private String[] xData = {"Time Distracted", "Time Focused"};
    PieChart pieChart;
    MainActivity mActivity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //asigno variables a botones y textos
        mStartButton = (Button) findViewById(R.id.start_button);
        mFinishButton = (Button) findViewById(R.id.finish_button);
        mUpdateButton = (Button) findViewById(R.id.update_button);
        mChronometerDistraction = (Chronometer) findViewById(R.id.chronometer);
        mChronometer = (Chronometer) findViewById(R.id.ChronometerDist);

        //estas son caracteristicas del piechart
        pieChart = (PieChart) findViewById(R.id.idPieChart);
        pieChart.setRotationEnabled(true);
        pieChart.setHoleRadius(25f);
        pieChart.setDrawEntryLabels(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setEntryLabelColor(Color.BLACK);

        //creando las variables de pantalla prendida o apagada
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);

        registerReceiver(new MyReceiver(), filter);
        //este es el boton de start que comienza ambos cronometros
        mStartButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                //Anque el boton de start comienza ambos cronometros, añado stop a los cronometros al principio por si el usuario le vuelve a dar start, asi los cronometros cuando empiezen a correr corren al mismo tiempo y no esten desincronizados
                mChronometer.stop();
                mChronometerDistraction.stop();
                addDataSet();
                //Los cronometros empezaran desde cero
                mChronometer.setBase(SystemClock.elapsedRealtime());
                mChronometerDistraction.setBase(SystemClock.elapsedRealtime());

                mChronometer.start(); //Comienza el cronometro general
                mChronometerDistraction.start(); // Comienza el cronometro de distraccion que cuenta el tiempo q la pantalla esta prendida
                TimeRunning = true;
            }

        });

        //Este es el boton de finish que terminara el tiempo y actualizara una ultima vez el pie chart. Note: aqui deberia a
        mFinishButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                mChronometer.stop();
                mChronometerDistraction.stop();
                TimeRunning = false;
                addDataSet();
            }

        });

        //Este boton actualiza el pie chart
        mUpdateButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                addDataSet();
            }
        });
    }


    //onResume se usa para cuando un usuario regresa a la aplicacion despues de haber apagado o haberse salido del app
    protected void onResume() {
        super.onResume();
        //crear y actualizar el pie chart
        addDataSet();

    }
    //toda esta mierda es para el piechart
    private void addDataSet() {
        float timeElapsed;
        float timeElapsed2;

        if(TimeRunning){
        timeElapsed = (SystemClock.elapsedRealtime() - mChronometer.getBase());
        timeElapsed2 = (SystemClock.elapsedRealtime() - mChronometerDistraction.getBase());
        }else {
        timeElapsed = 1;
        timeElapsed2 = 1;
        }

        //aqui asigno los porcentajes de concentracion y distraccion para el pie chart basado en los cronometros
        float[] yData = {(timeElapsed2/timeElapsed) * 100, (1-(timeElapsed2/timeElapsed)) * 100};

        ArrayList<PieEntry> pieEntries = new ArrayList<>();

        for (int i = 0; i < yData.length; i++){
            pieEntries.add(new PieEntry(yData[i], xData[i]));

        }

        //create the data set
        PieDataSet pieDataSet = new PieDataSet(pieEntries, "");
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueTextSize(12);
        pieDataSet.setValueTextColor(Color.BLACK);

        //add colors to dataset
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.RED);
        colors.add(Color.GREEN);
        pieDataSet.setColors(colors);

        //create pie leged to chart
        Legend legend = pieChart.getLegend();
        legend.setForm(Legend.LegendForm.CIRCLE);


        //create pie data object
        PieData pieData = new PieData(pieDataSet);
        pieData.setValueFormatter(new PercentFormatter());
        pieChart.setData(pieData);
        pieChart.invalidate();
    }
    //esta clase que cree detectara si la pantalla esta prendida o no y tomara una accion dependiendo de esa condicion
    public class MyReceiver extends BroadcastReceiver {
        MainActivity mActivity;
        @Override
        public void onReceive(Context arg0, Intent arg1) {
            mActivity = (MainActivity) arg0;
            //pantalla esta prendida
            if(arg1.getAction().equals(Intent.ACTION_SCREEN_ON)) {
                //Si el booleano ResumeTimer es true (el cronometro empezara a contar desde el valor de la ultima pausa ya que se apago la pantalla )y timerunning es true (el usuario le dio start) resume el tiempo en que se quedo el cronometro
                if (ResumeTimer && TimeRunning) {
                    mChronometerDistraction.setBase((mChronometerDistraction.getBase() + SystemClock.elapsedRealtime() - lastPause));
                    mChronometerDistraction.start();
                    ResumeTimer = false; //ResumeTimer se vuelve hacer falso
                }
                //pantalla esta apagada
            } else if(arg1.getAction().equals(Intent.ACTION_SCREEN_OFF)) {

                //Si la pantalla se apago y el tiempo esta corriendo, deten el tiempo, coge el tiempo en que se pauso, booleano ResumeTimer es true
                if (TimeRunning) {
                    lastPause = SystemClock.elapsedRealtime();
                    mChronometerDistraction.stop();
                    ResumeTimer = true;
                }
            }
        }
    }
}
